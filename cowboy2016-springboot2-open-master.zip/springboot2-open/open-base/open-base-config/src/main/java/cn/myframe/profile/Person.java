package cn.myframe.profile;

/**
 * @Author: ynz
 * @Date: 2018/12/24/024 18:09
 * @Version 1.0
 */
public interface Person {

    void say();
}
