package cn.myframe.leetcode;

import java.util.*;

/**
 *
 * 数组排序Arrays.sort(nums)
 */
public class Demo2 {

    public List<List<Integer>> threeSum(int[] nums) {
        List<List<Integer>> resultList = new ArrayList<>();
        Arrays.sort(nums);

        return resultList;
    }

    public static void main(String[] args) {

    }
}
