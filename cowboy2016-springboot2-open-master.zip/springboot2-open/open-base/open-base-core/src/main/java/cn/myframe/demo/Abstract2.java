package cn.myframe.demo;

/**
 * @Author: ynz
 * @Date: 2019/12/6/006 14:40
 * @Version 1.0
 */
public abstract class Abstract2 {
    public static void main(String[] args){

        System.out.println("1");
    }
}
