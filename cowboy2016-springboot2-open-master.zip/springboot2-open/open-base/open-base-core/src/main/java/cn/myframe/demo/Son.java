package cn.myframe.demo;

/**
 * @Author: ynz
 * @Date: 2019/2/27/027 16:52
 * @Version 1.0
 */
public class Son  extends Father{

    public void hello(){
        super.say2();
    }

    public static void main(String[] args) {

    }
}
