package cn.myframe.demo;

/**
 * @Author: ynz
 * @Date: 2019/2/27/027 16:51
 * @Version 1.0
 */
public class Father {
    private void say(){

    }

    public void say2(){

    }
}
