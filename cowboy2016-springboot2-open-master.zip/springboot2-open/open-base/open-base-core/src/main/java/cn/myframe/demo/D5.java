package cn.myframe.demo;

/**
 * @Author: ynz
 * @Date: 2019/12/4/004 14:13
 * @Version 1.0
 */
public class D5 {

    public static void main(String[] args) {
        System.out.println("this is D5");
    }
}
