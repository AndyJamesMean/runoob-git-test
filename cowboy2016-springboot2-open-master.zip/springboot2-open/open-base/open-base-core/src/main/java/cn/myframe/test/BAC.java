package cn.myframe.test;

/**
 * @Author: ynz
 * @Date: 2019/11/18/018 15:06
 * @Version 1.0
 */
public class BAC {

    private Byte[] b = new Byte [1024*1024*10];
    private String str =new String("bbbbbbbbbbbb");
}
