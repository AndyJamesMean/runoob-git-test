package cn.myframe.demo;

/**
 * @Author: ynz
 * @Date: 2019/2/21/021 12:30
 * @Version 1.0
 */
public class MyClassLoader extends ClassLoader {



    public static void main(String[] args) {
       byte a = 1;byte b = 2;
       Byte A =1;Byte B = 2;
       int c = A+B;

    }

}
