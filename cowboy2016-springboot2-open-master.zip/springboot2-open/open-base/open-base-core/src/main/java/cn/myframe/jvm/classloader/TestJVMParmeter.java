package cn.myframe.jvm.classloader;

/**
 * @Author: ynz
 * @Date: 2019/10/11/011 14:33
 * @Version 1.0
 */
public class TestJVMParmeter {

    public static void main(String[] args) throws InterruptedException {
        while (true){
            System.out.println("start.............");
            byte[] b = new byte[5000*1000];
            Thread.sleep(1*1000);
        }

    }
}
