package cn.myframe.test;

/**
 * @Author: ynz
 * @Date: 2019/8/23/023 14:00
 * @Version 1.0
 */
public class TestRedis {
}
