package cn.myframe.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: ynz
 * @Date: 2019/1/28/028 9:44
 * @Version 1.0
 */
public class Demo1 {


    final static  int a = 0;

    public static void main(String[] args) {
        Boolean b = false;
        Integer integer = 0 ;




    }

    public void abc(){
        int b = 0;
    }
}
