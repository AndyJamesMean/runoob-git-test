package cn.myframe.cglib;

/**
 * <p/>
 *
 * @author cs12110 created at: 2019/1/2 16:50
 * <p>
 * since: 1.0.0
 */
public class MyService {

    public void say(String something) {
        System.out.println(/*this + ":" +*/ something);
    }
}
