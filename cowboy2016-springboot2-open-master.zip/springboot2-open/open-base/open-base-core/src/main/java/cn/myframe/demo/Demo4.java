package cn.myframe.demo;

/**
 * @Author: ynz
 * @Date: 2019/6/10/010 8:53
 * @Version 1.0
 */
public class Demo4 {
    public static void main(String[] args) {
        System.out.println(Integer.MIN_VALUE);
    }
}
