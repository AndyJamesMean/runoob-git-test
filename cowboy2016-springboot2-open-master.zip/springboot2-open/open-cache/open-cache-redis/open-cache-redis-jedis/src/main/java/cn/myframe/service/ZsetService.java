package cn.myframe.service;

import org.springframework.stereotype.Service;

/**
 * @Author: ynz
 * @Date: 2019/1/23/023 8:39
 * @Version 1.0
 */
@Service
public class ZsetService {

}
