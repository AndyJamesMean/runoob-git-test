package cn.myframe.controller;

/**
 * @Author: ynz
 * https://blog.csdn.net/suo082407128/article/details/86231681
 */
public class SetController {
}
