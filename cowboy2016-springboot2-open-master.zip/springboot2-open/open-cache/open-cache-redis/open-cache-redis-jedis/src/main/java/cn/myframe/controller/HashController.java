package cn.myframe.controller;

/**
 * @Author: ynz
 * https://blog.csdn.net/xinhuashudiao/article/details/84906447
 */
public class HashController {
}
