package cn.myframe.sharding;

/**
 * @Author: ynz
 * @Date: 2019/6/6/006 16:54
 * @Version 1.0
 */
public class DatabaseShardingAlgorithm {
}
