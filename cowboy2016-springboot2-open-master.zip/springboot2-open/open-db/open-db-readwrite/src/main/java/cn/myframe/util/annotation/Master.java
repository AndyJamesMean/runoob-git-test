package cn.myframe.util.annotation;

public @interface Master {
}
