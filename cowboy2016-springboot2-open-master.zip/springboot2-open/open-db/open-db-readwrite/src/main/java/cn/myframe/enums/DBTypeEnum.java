package cn.myframe.enums;

public enum DBTypeEnum {

    MASTER, SLAVE1, SLAVE2;
}
