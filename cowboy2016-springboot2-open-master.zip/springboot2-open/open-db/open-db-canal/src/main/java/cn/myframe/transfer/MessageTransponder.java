package cn.myframe.transfer;

/**
 * 信息转换类继承 runnable，接口层
 *
 */
public interface MessageTransponder extends Runnable {
}
